function inline_worker( _inline_blob_code, _import_ext_scripts_array )
{
    this.blob = new Blob( [ _inline_blob_code ] );
    this.blobURL = window.URL.createObjectURL( this.blob );
    this.worker = new Worker( this.blobURL );
    var _l = window.location.href.split( "/" ) ;
    this.location = _l.slice( 0, _l.length - 1 ).join( "/" ) + "/" ;

    this.worker.postMessage( { id : "import",
                               location : this.location,
                               scripts : _import_ext_scripts_array }
                           );

    // this is the listener to capture messages from above custom script
    this.worker.onmessage = function(e)
    {
        switch( e.data.id )
        {
            case "output": console.log( e.data.msg ) ; break ;
            case "stop": this.terminate(); break ;
        }
    };
}

inline_worker.prototype.run = function()
{
    this.worker.postMessage( { id : "run" } );
    window.URL.revokeObjectURL( this.blobURL );
}

inline_worker.prototype.stop = function()
{
    this.worker.postMessage( { id : "stop" } );
}