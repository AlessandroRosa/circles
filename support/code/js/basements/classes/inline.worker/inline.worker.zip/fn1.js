function fn1()
{
    console.log( "this is a call to fn1" );
}