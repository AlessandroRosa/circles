function fn2()
{
    console.log( "this is a call to fn2" );
}